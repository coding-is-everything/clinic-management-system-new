---
name: Clinical Ops Infrastructure
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#924628'
  on-tertiary: '#ffffff'
  tertiary-container: '#b05e3d'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#773215'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  sidebar-width: 260px
---

## Brand & Style

The design system is engineered for high-stakes enterprise healthcare administration. The personality is clinical, authoritative, and stoic, prioritizing operational reliability over aesthetic flair. It adopts a **Corporate / Modern** style with a focus on information density and visual precision.

The target audience consists of Platform Super Administrators who manage complex multi-tenant environments. Consequently, the UI avoids decorative elements in favor of a highly structured, systematic approach that minimizes cognitive load during critical decision-making. The emotional response should be one of absolute security and technical confidence.

## Colors

The palette is rooted in medical professionalism. The **Deep Medical Teal** serves as the primary action color, providing a sense of calm and hygiene. **Healthcare Blue** is utilized for secondary navigational elements and provisioning states.

The background uses a **Soft Clinical Blue-Gray** to reduce eye strain during long shifts, while application surfaces remain pure white to provide maximum contrast for data. Semantic colors are strictly reserved for status communication:
- **Green:** Active tenants and healthy system nodes.
- **Amber:** Expiring licenses or non-critical warnings.
- **Red:** Suspended accounts or critical system failures.
- **Blue:** In-progress provisioning or background tasks.
- **Gray:** Deactivated or archived entities.

## Typography

This design system utilizes **Inter** exclusively to ensure maximum legibility across dense data grids and technical forms. The typographic scale is compact to allow for high information density.

- **Headlines:** Use a semi-bold weight with slight negative letter-spacing to maintain authority without appearing "loud."
- **Data Labels:** Small, uppercase labels with increased letter-spacing are used for table headers and metadata descriptors.
- **Body Text:** 14px is the standard for primary data, while 13px is utilized for secondary "supporting" information or dense table cells.
- **Readability:** Ensure a minimum contrast ratio of 4.5:1 for all text against its background.

## Layout & Spacing

The layout follows a **Fixed Grid** model for the central content area (max 1440px) to ensure data scanning remains predictable. A permanent left-hand sidebar (260px) provides primary navigation.

- **Rhythm:** A 4px baseline grid governs all spacing.
- **Data Tables:** Use a compact vertical padding (8px) for table rows to maximize the number of visible records.
- **Multi-step Wizards:** Content is centered in a narrower 800px column within the main viewport to maintain focus.
- **Breakpoints:**
  - **Desktop (1280px+):** Full sidebar and 12-column content grid.
  - **Tablet (768px - 1279px):** Collapsed sidebar (icon-only) and 8-column grid.
  - **Mobile (<767px):** Single column, 16px margins, hidden sidebar with hamburger menu.

## Elevation & Depth

To maintain a "clinical" and flat aesthetic, elevation is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Level 0 (Background):** Soft Blue-Gray (#F8FAFC).
- **Level 1 (Main Surface):** White (#FFFFFF) with a 1px border (#E2E8F0). No shadow. Used for the primary content area.
- **Level 2 (Cards/Modals):** White with a very soft, diffused shadow (0px 4px 6px -1px rgba(0,0,0,0.05)).
- **Level 3 (Popovers/Menus):** White with a defined border and medium shadow (0px 10px 15px -3px rgba(0,0,0,0.1)).

Interactive elements should not "float" high above the page; they should feel integrated into the technical architecture.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding takes the edge off the clinical interface without appearing "playful" or consumer-grade.

- **Inputs & Buttons:** 4px (0.25rem) radius.
- **Cards & Modals:** 8px (0.5rem) radius for distinct containment.
- **Status Badges:** Fully rounded (pill) to distinguish them immediately from interactive buttons.
- **Selection Indicators:** Use sharp 0px vertical bars on the left edge of active sidebar items to denote focus.

## Components

### Application Shell
A persistent top bar contains the tenant switcher and global search. The sidebar handles primary navigation (Dashboard, Tenants, Users, Billing, Logs).

### Data Tables
Tables are the core of the platform. Features include:
- Fixed headers on scroll.
- Inline status badges.
- "Actions" column using a simple horizontal dots icon.
- Hover states using a light tint of the primary color (#F0FDFA).

### Multi-step Wizards (Steppers)
For tenant onboarding, use a horizontal stepper at the top of the modal. Steps should clearly indicate `Complete` (Teal), `In Progress` (Blue), and `Pending` (Gray).

### Status Indicators & Badges
- **Status Badges:** Small text, uppercase, with a light background tint of the semantic color (e.g., Active = Teal background at 10% opacity with Teal text).
- **KPI Cards:** Display critical metrics (e.g., "Active Tenants") using `headline-md` for the value and `label-md` for the title.

### Input Fields
Standardized with a 1px border (#CBD5E1). Active/Focus state uses a 1px Teal border with a 2px Teal outer glow at 20% opacity.

### Secure Confirmation Modals
For destructive actions (e.g., Suspending a Tenant), use a "Critical" red primary button and require the administrator to type the name of the tenant to confirm.