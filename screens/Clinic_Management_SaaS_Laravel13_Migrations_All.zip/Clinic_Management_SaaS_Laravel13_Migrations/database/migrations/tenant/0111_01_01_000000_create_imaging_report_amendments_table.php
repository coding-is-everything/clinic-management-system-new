<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tenant';

    public function up(): void
    {
        Schema::create('imaging_report_amendments', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 36);
            $table->string('name', 190)->nullable();
            $table->string('status', 40)->nullable();
            $table->json('filters')->nullable();
            $table->json('result_metadata')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->dateTime('created_at', 6)->useCurrent();
            $table->dateTime('updated_at', 6);
            $table->dateTime('deleted_at', 6)->nullable();
            $table->unique(['public_id'], 'uq_imaging_report_amendments_public_id');
            $table->index(['status'], 'idx_imaging_report_amendments_status');
            $table->index(['created_at'], 'idx_imaging_report_amendments_created_at');
            $table->index(['updated_at'], 'idx_imaging_report_amendments_updated_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('imaging_report_amendments');
    }
};
