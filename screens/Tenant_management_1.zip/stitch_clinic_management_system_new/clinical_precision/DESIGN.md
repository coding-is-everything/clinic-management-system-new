---
name: Clinical Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#191c1e'
  on-tertiary-container: '#818486'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

The design system is engineered for high-stakes healthcare environments, prioritizing cognitive clarity, speed of data retrieval, and an unwavering sense of reliability. The brand personality is clinical yet empathetic—balancing the rigor of medical data with the human needs of clinicians and administrators.

The visual style is **Corporate Modern with a Minimalist focus**. It utilizes a clean, "White-Space First" philosophy to reduce visual noise in data-heavy screens. Depth is used sparingly through subtle tonal shifts rather than aggressive shadows, ensuring the UI feels grounded and professional. Every element serves a functional purpose, following a "Utility over Decoration" mandate.

## Colors

This design system utilizes a structured hierarchy of slate blues and clinical whites to establish authority.

- **Primary (Deep Slate):** Used for persistent navigation, headers, and text to provide a high-contrast foundation.
- **Action (Blue):** A vibrant, accessible blue reserved strictly for interactive elements like primary buttons and active states.
- **Surface (Clinical White):** The primary background color to ensure maximum legibility and a sterile, clean aesthetic.
- **Status Colors:** Specific shades of Green, Amber, and Red are calibrated for AA accessibility on white backgrounds, used exclusively for badges, validation, and critical alerts.
- **Neutral/Border:** Mid-tone slates used for secondary text and subtle borders to define structure without adding bulk.

## Typography

The design system relies on **Inter** for its exceptional legibility in technical contexts and wide range of weights.

- **Scale:** A tight typographic scale ensures that data-dense tables remain readable. 
- **Hierarchy:** Use `label-md` for table headers and section titles to provide a clear "scan-line" for the eye.
- **Body Text:** `body-md` is the workhorse for all data entry and standard text. Use `body-sm` for secondary metadata or audit log timestamps.
- **Contrast:** Ensure all text maintains at least a 4.5:1 contrast ratio against background colors.

## Layout & Spacing

The layout uses a **Fluid Grid System** with defined maximum widths for readability on ultra-wide monitors.

- **Grid:** A 12-column grid is used for desktop views. For data-heavy dashboards, use a "sidebar-main" layout where the sidebar is fixed at 280px and the main content area is fluid.
- **Rhythm:** An 8pt spatial system (with a 4pt sub-grid) governs all margins and padding. 
- **Density:** Provide two density modes for tables: "Standard" (16px vertical padding) and "Compact" (8px vertical padding) for expert users managing high volumes of patient records.
- **Mobile:** Transition to a single-column layout with 16px margins; prioritize the "Action Bar" at the bottom of the screen for one-handed clinical use.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Level 0 (Base):** The main background (`#F8FAFC`).
- **Level 1 (Card/Surface):** White surfaces (`#FFFFFF`) with a 1px border (`#E2E8F0`). No shadow is used here to maintain a flat, modern look.
- **Level 2 (Popovers/Dropdowns):** White surfaces with a soft, 10% opacity slate shadow (0px 4px 12px) to suggest temporary presence.
- **Interactions:** Hover states on interactive rows should use a subtle gray tint (`#F1F5F9`) instead of elevation changes to avoid "jumping" pixels during rapid scanning.

## Shapes

The shape language is **Soft and Precise**. 

- **Standard Components:** Buttons, input fields, and cards use a 4px (0.25rem) corner radius. This provides a professional look that is slightly more approachable than sharp corners without feeling "bubbly."
- **Status Badges:** Use a higher roundedness (12px or more) to create a distinct visual difference between clickable buttons and informative tags.
- **Active Indicators:** Use sharp vertical bars (3px wide) on the left side of active navigation items or table rows to indicate focus.

## Components

- **Data Tables:** Feature sticky headers and the first column (e.g., Patient Name). Use alternating row colors or subtle borders. Header cells should use `label-md` with sorting icons.
- **Status Badges:** 
  - *Pending:* Neutral background with dark text.
  - *In Progress:* Blue tint background with Blue text.
  - *Completed:* Green tint background with Green text.
- **Form Fields:** Use "Top-aligned" labels for speed. Focus states must use a 2px blue ring. Error states must include an icon and descriptive text below the field.
- **Audit Logs:** A specialized list component using `body-sm`. Timestamps are right-aligned and muted. Action types (e.g., "EDITS") are highlighted in `label-sm`.
- **Buttons:**
  - *Primary:* Solid Slate Blue with white text.
  - *Secondary:* Outline Slate with transparent background.
  - *Destructive:* Solid Red for critical deletions (e.g., "Delete Record").
- **Search:** A persistent global search in the top bar with a keyboard shortcut hint (`Cmd+K`).